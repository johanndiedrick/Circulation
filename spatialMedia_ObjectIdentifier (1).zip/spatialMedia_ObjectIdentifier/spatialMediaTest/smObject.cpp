//
//  smObject.cpp
//  spatialMediaTest
//
//  Created by Jared Schiffman on 2/23/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#include <iostream>
#include "smObject.h"

smObject::smObject( int _ID )
{
    ID = _ID;
}

void    smObject::acceptPixel( int x, int y )
{
    // process incoming pixels here
}








